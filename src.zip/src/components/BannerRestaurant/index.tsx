import { BannerContainer, Title, Type } from './styles'

type Props = {
  title: string
  type: string
  image: string
}

const BannerRestaurant = ({ title, type, image }: Props) => (
  <BannerContainer style={{ backgroundImage: `url(${image})` }}>
    <div className="container">
      <Type>{type}</Type>
      <Title>{title}</Title>
    </div>
  </BannerContainer>
)

export default BannerRestaurant
