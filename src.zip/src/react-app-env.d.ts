/// <reference types="react-scripts" />

declare module 'react-icons/fa' {
  export * from 'react-icons/fa/index'
}
