import styled from 'styled-components'

export const Container = styled.div`
  background-color: #E66767;
  padding-bottom: 40px;
`
